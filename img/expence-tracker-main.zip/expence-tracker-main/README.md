# LCRN07 - Expense Tracker App (Expo)

## [Watch it on YouTube](https://youtu.be/uBcpWOQqbAQ)

In this episode of "Let’s Code React Native" series, we are going to build a clean looking Expense Tracker App based on the design created by Anastasiia on Dribbble.

Be sure to subscribe to our YouTube channel for more videos like this!

## Table of Contents

| Code | Project | Preview | Inspiration | No. of Screens |
| ------ | ------ | ------ | ------ | ------ |
| LCRN07 | [Expense Tracker App](https://youtu.be/uBcpWOQqbAQ) | <img src="https://cdn.dribbble.com/users/2141764/screenshots/6037420/money_tracker_app.png?compress=1&resize=1200x900" width="120" /> | [View](https://dribbble.com/shots/6037420-Expense-Tracker-App) | 1 |

## Contributors

<a href="https://github.com/byprogrammers/LCRN07-expense-tracker-app/graphs/contributors">
   <img src="https://contrib.rocks/image?repo=byprogrammers/lets-code-react-native" />
</a>

